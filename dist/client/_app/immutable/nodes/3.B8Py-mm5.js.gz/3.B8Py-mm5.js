import{s}from"../chunks/scheduler.DTn6sg0E.js";import{S as t,i as e}from"../chunks/index.BrvKFv8V.js";class l extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{l as component};
